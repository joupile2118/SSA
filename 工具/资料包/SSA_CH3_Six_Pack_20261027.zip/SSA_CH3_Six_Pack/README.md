# 第三章六件套

《随机信号分析（第5版）》第3章“平稳性与功率谱密度”。版本：2026-10-27。

本包含6份PDF及同名自包含LaTeX，共100页。教材复用DSH已验收版本；其余五份按“作业题册→作业答案→考频→复习题集→习题集答案”依次验收。

| 顺序 | 文档 | 页数 | PDF | LaTeX |
|---|---|---:|---|---|
| 1 | 教材重排版 | 38 | [阅读](01_Textbook/SSA_Textbook_CH3_zh.pdf) | [源码](01_Textbook/SSA_Textbook_CH3_zh.tex) |
| 2 | 英文作业题册 | 10 | [阅读](02_Homework/SSA_Homework_3_English.pdf) | [源码](02_Homework/SSA_Homework_3_English.tex) |
| 3 | 英文作业详解 | 6 | [阅读](03_Homework_Solutions/SSA_Homework_3_Solutions_English.pdf) | [源码](03_Homework_Solutions/SSA_Homework_3_Solutions_English.tex) |
| 4 | 中文考频报告 | 10 | [阅读](04_Exam_Frequency/SSA_CH3_Exam_Frequency_Report.pdf) | [源码](04_Exam_Frequency/SSA_CH3_Exam_Frequency_Report.tex) |
| 5 | 英文复习题集 | 23 | [阅读](05_Review_Problems/SSA_CH3_Review_Problem_Set.pdf) | [源码](05_Review_Problems/SSA_CH3_Review_Problem_Set.tex) |
| 6 | 中文习题详解 | 13 | [阅读](06_Review_Solutions/SSA_CH3_Review_Solutions_zh.pdf) | [源码](06_Review_Solutions/SSA_CH3_Review_Solutions_zh.tex) |

## 题单与复习安排

必做：3.4、3.5、3.9、3.14、3.16、3.21、3.25。选做：3.1、3.7、3.19。截止通知原文为“第三章结束后一周”，未补造日历日期。复习题集21题/7天，完整覆盖全部10道作业，题源、改编与教材小节均标明。题册/题集每题一页留白；答案连续排版。

八套核心分0/0/9/19/17/25/29/7，均值13.25，近期四套19.50。同一计分小问仅有一个主归属，间接标签不重复计分。来源与覆盖见metadata中的标注JSON；原卷路径指本地课程资料位置，原卷不包含在本包内。

## 编译

需安装TeX Live与相应字体，中文使用XeLaTeX；所有tex均可作为单一源文件编译，无外部题图或input依赖。请把编译中间产物放到临时目录。例如：

```sh
mkdir -p build
xelatex -interaction=nonstopmode -output-directory=build 06_Review_Solutions/SSA_CH3_Review_Solutions_zh.tex
```

通常编译2–3遍以收敛引用和表格宽度，教材建议4遍。发布前已将六份源码分别复制到独立目录成功重编译，并确认页数和提取正文与发布PDF一致。

## 条件与边界

- 3.16先证明X的均值为0，再使用E[A²]=13，方差为260。
- 3.1重复时刻联合分布奇异；有限方差独立采样模型不能偷换成Dirac相关的理想白噪声。
- 3.19(3)在p>0时谱不可积，只给广义相关，不把δ(0)当作有限均方值；p=0、p<0分别处理。
- 202312和202512的两处原卷模型冲突已明示；改编题的新增条件与原题区分。

## 验收与完整性

metadata/Verification.json记录结构、数学与来源核验摘要；Files.json与SHA256SUMS列出逐文件哈希。全部五份新PDF的62页已渲染目检，0溢出、无缺字、无未解析引用；教材保留既有验收版本。

本包为课程学习整理资料及自制解答，不是官方英译或官方评分答案。教材及原课程材料的权利归各自权利人所有。
